Añade tus propios archivos:
- background.jpg -> la imagen de fondo de Pinterest
- profile.jpg -> tu foto de perfil de Pinterest
- music.mp3 -> la canción que quieras usar
